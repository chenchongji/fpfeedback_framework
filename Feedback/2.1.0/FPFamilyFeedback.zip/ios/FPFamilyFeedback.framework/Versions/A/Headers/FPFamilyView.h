//
//  FPFamilyView.h
//  Feedback
//
//  Created by 李焱 on 2021/4/12.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedbackStoreModuleBean.h"
@class FPFamilyProductQRView;
NS_ASSUME_NONNULL_BEGIN

@protocol FPFamilyViewDelegate <NSObject>

- (void)closeBtnClick;
- (void)shareBtnClick;
- (void)adviseBtnClick;
- (void)skipAppStoreClick:(NSString *)appId skipToAfUrl:(BOOL)toAf originalData:(NSString *)originalDataStr isFromDetail:(BOOL)isFromDetail;

- (void)openAppClick:(FPFamilyFeedbackStoreModuleBean *)bean isFromDetail:(BOOL)isFromDetail;
- (void)skipToAppSoreClick:(FPFamilyFeedbackStoreModuleBean *)bean isFromDetail:(BOOL)isFromDetail;
- (void)qrSkipAppStoreClick:(NSString *)appId skipToAfUrl:(BOOL)toAf;

@end

@interface FPFamilyView : UIView
@property(nonatomic, strong) FPFamilyProductQRView *qrView;
@property(nonatomic, weak) id<FPFamilyViewDelegate> delegate;

- (void)setupStoreModuleData:(NSArray *)beans;
- (void)screenOrientationChange:(CGRect)rect;
- (void)detailSkipAppStoreClick:(FPFamilyFeedbackStoreModuleBean *)bean;
@end

NS_ASSUME_NONNULL_END
