//
//  FPFamilyViewController.h
//  AFNetworking
//
//  Created by 李焱 on 2021/4/9.
//

#import <UIKit/UIKit.h>
#import "FPFamilyViewModel.h"
#import "FPFamilyView.h"

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyViewController : UIViewController
@property(nonatomic, strong) FPFamilyView *familyView;
- (void)skipToAppSoreClick:(FPFamilyFeedbackStoreModuleBean *)bean;
@end

NS_ASSUME_NONNULL_END
