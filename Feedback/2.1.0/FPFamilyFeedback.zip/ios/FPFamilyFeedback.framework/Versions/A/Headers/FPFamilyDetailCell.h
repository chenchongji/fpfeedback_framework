//
//  FPFamilyDetailCell.h
//  FPFamilyFeedback
//
//  Created by qiaoming on 2021/9/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyDetailCell : UITableViewCell
-(void)resetData:(NSDictionary *)dic;
+(NSArray *)getContentHeight:(NSArray *)publicity_content;
@end

NS_ASSUME_NONNULL_END
