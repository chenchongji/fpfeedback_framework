//
//  FPTimerProxy.h
//  FPFamilyFeedback
//
//  Created by qiaoming on 2021/6/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FPTimerProxy : NSProxy
@property (weak, nonatomic) id target;
@end

NS_ASSUME_NONNULL_END
