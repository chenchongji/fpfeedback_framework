//
//  FPFamilyDetailHeader.h
//  FPFamilyFeedback
//
//  Created by qiaoming on 2021/9/13.
//

#import <UIKit/UIKit.h>
#import "FPFamilyDetailFooter.h"

@class FPFamilyFeedbackStoreModuleBean;

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyDetailHeader : UIView
@property(nonatomic, copy) ShareClickCall getCallback;
@property(nonatomic, copy) ShareClickCall closeCallback;
- (instancetype)initWithFrame:(CGRect)frame bean:(FPFamilyFeedbackStoreModuleBean *)bean;
+(CGFloat)getHeight:(NSString *)str;
@end

NS_ASSUME_NONNULL_END
