//
//  FPFamilyDetailView.h
//  FPFamilyFeedback
//
//  Created by qiaoming on 2021/9/10.
//

#import <UIKit/UIKit.h>
@class FPFamilyFeedbackStoreModuleBean;

NS_ASSUME_NONNULL_BEGIN

@interface FPFamilyDetailView : UIView

@property(nonatomic, strong) UIImage *headerImage;
- (instancetype)initWithFrame:(CGRect)frame bean:(FPFamilyFeedbackStoreModuleBean *)bean;
-(void)showIn:(UIView *)view;
-(void)remove;

@end

NS_ASSUME_NONNULL_END
