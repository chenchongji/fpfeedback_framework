//
//  FPFamilyViewModel.h
//  Feedback
//
//  Created by 李焱 on 2021/4/12.
//

#import <Foundation/Foundation.h>
#import "FPFamilyFeedbackStoreApi.h"
#import "FPFamilyFeedbackStoreModuleBean.h"

NS_ASSUME_NONNULL_BEGIN

typedef void(^GetModuleDataCallBack)(NSArray* _Nullable);

@interface FPFamilyViewModel : NSObject

- (void)getStoreModuleData:(GetModuleDataCallBack)callBack;

@end

NS_ASSUME_NONNULL_END
