//
//  FPFamilyFeedBackSdk.h
//  feedback
//
//  Created by 李焱 on 2021/3/23.
//

#import <Foundation/Foundation.h>
#import "FPFamilyFeedBackParams.h"
@class FPFamilyViewController;
NS_ASSUME_NONNULL_BEGIN

typedef void(^ParamsCallBack)(FPFamilyFeedBackParams*);

@interface FPFamilyFeedBackSdk : NSObject

@property(nonatomic, strong) FPFamilyFeedBackParams *params;
//sdk内部使用字段,外部请勿修改
@property(nonatomic, strong) FPFamilyViewController * __nullable currentVC;
+(instancetype)shareInstance;
- (void)setup:(FPFamilyFeedBackParams *)params;
- (void)updateParams:(ParamsCallBack)callBack;
- (void)showInController:(UIViewController *)vc needFamily:(BOOL)needFamily;

- (void)setupEnvironment:(BOOL)isDebug;
- (void)setupModuleId:(NSInteger)moduleId;

@end

NS_ASSUME_NONNULL_END
