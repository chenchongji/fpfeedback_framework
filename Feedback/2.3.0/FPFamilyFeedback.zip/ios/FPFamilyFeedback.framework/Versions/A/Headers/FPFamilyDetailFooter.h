//
//  FPFamilyDetailFooter.h
//  FPFamilyFeedback
//
//  Created by qiaoming on 2021/9/13.
//

#import <UIKit/UIKit.h>
#import "FPFamilyFeedbackStoreModuleBean.h"

NS_ASSUME_NONNULL_BEGIN
typedef void (^ShareClickCall)(FPFamilyFeedbackStoreModuleBean *bean);

@interface FPFamilyDetailFooter : UIView
@property(nonatomic, copy) ShareClickCall callback;
@property(nonatomic, copy) ShareClickCall getCallback;
- (instancetype)initWithFrame:(CGRect)frame bean:(FPFamilyFeedbackStoreModuleBean *)bean;
+(CGFloat)getHeight;
@end

NS_ASSUME_NONNULL_END
